# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


admin:$1$bsfMUI13$II6NWx3.QnRZDsXaFVTmz.:Creative Kids Admin:admin@creativekidssa.com.au:admin,user
