<?php
/**
 * English language file for authpdo plugin
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */

$lang['connectfail']    = 'Failed to connect to database.';
$lang['userexists']     = 'Sorry, a user with this login already exists.';
$lang['writefail']      = 'Unable to modify user data. Please inform the Wiki-Admin';

//Setup VIM: ex: et ts=4 :
